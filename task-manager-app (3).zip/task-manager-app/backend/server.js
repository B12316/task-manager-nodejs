const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Task = require('./models/Task');

const app = express();
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/taskmanager', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Get all tasks
app.get('/tasks', async (req, res) => {
    try {
        console.log('Fetching all tasks...');
        const tasks = await Task.find();
        console.log('Tasks found:', tasks);
        res.json(tasks);
    } catch (err) {
        console.error('Error fetching tasks:', err);
        res.status(500).send(err.message);
    }
});

// Create new task
app.post('/tasks', async (req, res) => {
    try {
        console.log('Creating new task:', req.body);
        const task = new Task(req.body);
        const savedTask = await task.save();
        console.log('Task created:', savedTask);
        res.status(201).json(savedTask);
    } catch (err) {
        console.error('Error creating task:', err);
        res.status(500).send(err.message);
    }
});

// Update task
app.put('/tasks/:id', async (req, res) => {
    try {
        console.log('Updating task:', req.params.id, req.body);
        const task = await Task.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        console.log('Task updated:', task);
        res.json(task);
    } catch (err) {
        console.error('Error updating task:', err);
        res.status(500).send(err.message);
    }
});

// Delete task
app.delete('/tasks/:id', async (req, res) => {
    try {
        console.log('Deleting task:', req.params.id);
        const task = await Task.findByIdAndDelete(req.params.id);
        console.log('Task deleted:', task);
        res.json({ message: 'Task deleted successfully' });
    } catch (err) {
        console.error('Error deleting task:', err);
        res.status(500).send(err.message);
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});