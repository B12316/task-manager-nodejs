# ✅ Task Manager Web App

A responsive and interactive **Task Manager** web application built using **AngularJS (frontend)** and **Node.js + Express (backend)**.  
This app allows users to add, edit, complete, and delete tasks with real-time UI updates and backend API integration.

---

## 🚀 Features

- 📋 Add, view, and manage tasks
- ✏️ Edit existing tasks
- ✅ Mark tasks as complete
- 🗑️ Delete tasks with confirmation
- 📊 View total and completed task counts
- 🎯 Clean and responsive UI using HTML + CSS

---

## 🛠️ Tech Stack

### 🔹 Frontend:
- HTML5, CSS3
- AngularJS 1.8
- Font Awesome Icons
- Google Fonts (Roboto)

### 🔹 Backend:
- Node.js
- Express.js
- MongoDB (via Mongoose)
- CORS enabled

---

## 📂 Folder Structure

```
task-manager-app/
├── index.html       # Frontend (AngularJS UI)
├── app.js           # AngularJS controller
├── styles.css       # UI styling
├── server.js        # Backend server logic (not uploaded yet)
├── package.json     # Node.js project config
```

---

## 🖥️ How to Run

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the backend server:
   ```bash
   node server.js
   ```

3. Open `index.html` in browser or host on a local server

4. Use the app via browser at:
   ```
   http://localhost:3000
   ```

---

## 📸 UI Preview

> A clean interface with task counters, styling, and intuitive actions. 

---

## 👩‍💻 Created By

**Bhumika Patil**  
📧 Email: bhumikapatil145@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/in/bhumika-patil-819725218)

---

## 📌 Notes

- Ensure MongoDB server is running if backend is connected to DB  
- You can add hosting instructions (Render, Vercel) for deployment
