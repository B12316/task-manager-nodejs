angular.module('taskApp', [])
.controller('TaskController', function($scope, $http) {
    $scope.tasks = [];
    $scope.newTask = {};

    function loadTasks() {
        console.log('Loading tasks...');
        $http.get('http://localhost:3000/tasks')
            .then(function(response) {
                console.log('Tasks loaded:', response.data);
                $scope.tasks = response.data;
            })
            .catch(function(error) {
                console.error('Error loading tasks:', error);
            });
    }

    $scope.addTask = function() {
        console.log('Adding new task:', $scope.newTask);
        $http.post('http://localhost:3000/tasks', $scope.newTask)
            .then(function(response) {
                console.log('Task added successfully:', response.data);
                $scope.newTask = {};
                loadTasks();
            })
            .catch(function(error) {
                console.error('Error adding task:', error);
            });
    };

    $scope.deleteTask = function(id) {
        if (confirm('Are you sure you want to delete this task?')) {
            console.log('Deleting task:', id);
            $http.delete('http://localhost:3000/tasks/' + id)
                .then(function() {
                    console.log('Task deleted successfully');
                    loadTasks();
                })
                .catch(function(error) {
                    console.error('Error deleting task:', error);
                });
        }
    };

    $scope.updateTask = function(task) {
        console.log('Updating task:', task);
        $http.put('http://localhost:3000/tasks/' + task._id, task)
            .then(function(response) {
                console.log('Task updated successfully:', response.data);
                loadTasks();
            })
            .catch(function(error) {
                console.error('Error updating task:', error);
            });
    };

    $scope.editTask = function(task) {
        const newTitle = prompt('Edit task:', task.title);
        if (newTitle && newTitle !== task.title) {
            task.title = newTitle;
            $scope.updateTask(task);
        }
    };

    $scope.getCompletedCount = function() {
        return $scope.tasks.filter(task => task.completed).length;
    };

    // Load tasks when the controller initializes
    loadTasks();
});